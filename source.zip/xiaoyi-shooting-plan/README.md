# 小怡说车拍摄周计划源码

React + Vite + FullCalendar 6.1.21。

运行：npm ci，然后 npm run dev。构建：npm run build；检查：npm test。

本地开发端口4190。只开发与验收PC。修改保存在当前浏览器，不跨设备同步。

计划是依据2026-04-26公开作品补整理的示例，具体拍摄时间和地点待核对。网页没有下载或使用付费React Bits Pro源码。
