export type Phase = 'prep' | 'shoot' | 'post' | 'buffer'
export type Task = { id: string; title: string; date: string; start: string; end: string; phase: Phase; owner: string; boss: boolean; location: string; output: string; note: string; verified?: boolean }
export const phases: Record<Phase, { label: string; color: string }> = {
  prep: { label: '拍前准备', color: '#a9b5f5' },
  shoot: { label: '现场拍摄', color: '#79d9c5' },
  post: { label: '后期交付', color: '#e7bb88' },
  buffer: { label: '休息 / 机动', color: '#9ba4ac' },
}
export const sample = {
  title: '大众9X · 大家庭用车体验',
  url: 'https://www.douyin.com/video/7632769091564903410',
  originalTitle: '29.98万起大满配！上汽大众9X专治大家庭用车痛点',
  published: '2026-04-26 10:44', duration: '05:24', shootDate: '2026-04-24',
  provenance: '2026-11-01 核对抖音公开页：作者、作品标题、时长及发布时间。未取得当年通告单、原始素材时间戳或完整逐镜记录。',
  assumption: '补整理说明：以公开发布时间为交付点倒排。除发布点外，拍摄日期、钟点、地点、人员到场与工时均为拟定，待当事人及原始记录核对。',
}
const task = (id: string, date: string, start: string, end: string, title: string, phase: Phase, owner: string, boss: boolean, output: string, location = '工作室 / 线上', note = ''): Task => ({ id, date: `2026-04-${date}`, start, end, title, phase, owner, boss, output, location, note })
export const seedTasks: Task[] = [
  task('research','20','09:00','10:30','资料与人群研究','prep','策划',false,'车型资料核对表、家庭用车问题清单；价格、配置逐项回到资料确认。'),
  task('angle','20','11:00','12:00','选题与开头方案','prep','策划',false,'一条主线＋两个开头备选，明确这条视频回答什么问题。'),
  task('brief','20','15:00','15:30','老板确认选题','prep','老板 / 策划',true,'确认内容方向、表达边界、出镜档期；形成一页拍摄简报。'),
  task('script','21','09:00','10:30','口播脚本初稿','prep','策划',false,'开头、家庭痛点、体验段落、收尾；标记待核实信息。'),
  task('storyboard','21','11:00','12:00','拆分镜与必拍单','prep','策划 / 摄像',false,'口播对画面；列出外观、空间、细节、体验和替代镜头。'),
  task('book','21','14:00','15:00','预约车辆与场地','prep','统筹 / 商务',false,'车辆借用时段、场地许可、到场联系人；地点未确认前不写具体地址。','车辆 / 场地方（待确认）'),
  task('equipment','22','09:00','10:00','器材与收音检查','prep','摄像 / 辅助拍摄',false,'电池、存储卡、相机、收音与备机检查表；试录回放。'),
  task('scout','22','10:30','12:00','踩点与路线确认','prep','摄像 / 统筹',false,'光线、噪声、停车和转场时间；道路拍摄方式与备用静态方案。','拍摄场地 / 路线（待确认）'),
  task('logistics','22','16:00','16:30','落实出行与保障','prep','统筹',false,'集合点、车辆接送、用餐、天气备选；不把等待时间安排为老板出镜。'),
  task('props','23','09:00','10:00','道具与场景准备','prep','策划 / 辅助拍摄',false,'按分镜备齐演示物品；检查车内整洁、电量 / 油量与功能状态。'),
  task('approve','23','11:00','11:30','老板确认口播','prep','老板 / 策划',true,'确认最终口播、读音、产品表述；把临场改稿压到最少。'),
  task('callsheet','23','14:00','15:00','发送通告与镜头表','prep','策划 / 统筹',false,'通告写清集合、开拍、老板参与段、联系人和备用方案；本页仅拟定，未发送。'),
  task('setup','24','08:30','09:00','团队到场 · 布置','prep','摄像 / 辅助拍摄',false,'完成构图、光线和收音测试；车辆、道具、场地就绪。','拍摄场地（待确认）'),
  task('arrival','24','09:00','09:30','老板到场 · 妆发','prep','老板 / 统筹',true,'服装、妆发、麦克风确认；同步当日顺序与收工时间。','拍摄场地（待确认）'),
  task('readthrough','24','09:30','10:00','走词 · 镜头走位','prep','老板 / 策划 / 摄像',true,'顺口播、试走位；回看一段收音和画面，确认后再开拍。','拍摄场地（待确认）'),
  task('opening','24','10:00','11:30','开场口播 · 外观','shoot','老板出镜 / 摄像主拍',true,'完成主开头与备选开头、外观段；策划负责提词、连续性与漏拍标记。','静态场地（待确认）'),
  task('exterior','24','11:30','12:00','外观细节空镜','shoot','摄像 / 辅助拍摄',false,'补外观细节和转场镜头；老板可离镜休息。','静态场地（待确认）'),
  task('lunch','24','12:00','13:00','午餐 · 休息','buffer','全组',false,'预留用餐、休息与设备充电，不安排连续口播。','拍摄场地附近（待确认）'),
  task('interior','24','13:00','14:30','车内空间 · 家用体验','shoot','老板出镜 / 摄像主拍',true,'按脚本演示家庭使用场景；逐项勾掉必拍单，核对前后连续性。','车辆静止场地（待确认）'),
  task('details','24','14:30','15:00','内饰细节空镜','shoot','摄像 / 辅助拍摄',false,'补车内细节、手部操作与承接镜头；老板离镜休息。','车辆静止场地（待确认）'),
  task('transfer','24','15:00','15:30','休息 · 转场机动','buffer','全组',false,'检查已拍素材；根据天气、噪声和现场情况调整后半程。','转场路线（待确认）'),
  task('drive','24','15:30','16:30','体验段 · 动态画面','shoot','老板 / 摄像 / 驾驶人员',true,'完成体验反馈和动态补充画面；驾驶人员不兼顾手持拍摄，条件不具备时改静态口播。','合规拍摄路线（待确认）'),
  task('pickup','24','16:30','17:00','结尾 · 查漏补拍','shoot','老板 / 策划 / 摄像',true,'逐条核对分镜，补结尾、关键口播和收音不合格段。','收尾场地（待确认）'),
  task('release','24','17:00','17:30','素材快检 · 老板收工','post','老板 / 策划 / 摄像',true,'确认必拍镜头和关键声音可用后再安排老板离场。','拍摄场地（待确认）'),
  task('backup','24','17:30','18:30','双份备份 · 剪辑交接','post','摄像 / 策划',false,'至少两处备份并抽查可读性；交接素材目录、优选条次、脚本、补拍标记和截止时间。'),
  task('rough','25','09:00','11:30','粗剪与信息核查','post','剪辑 / 策划',false,'按口播和画面主线出粗剪；核对字幕、车型信息和素材缺口。'),
  task('review','25','14:00','14:30','老板看粗剪','post','老板 / 策划 / 剪辑',true,'集中确认开头、核心表述和需删改段；修改意见一次汇总。'),
  task('finalcut','25','15:00','17:00','精剪 · 封面与文案','post','剪辑 / 策划',false,'修订版、封面和发布文案；核对声音、字幕、画幅与首尾。'),
  task('qc','26','09:00','10:00','发布前检查','post','策划 / 剪辑',false,'完整回看最终导出，检查错字、事实、声音、封面和链接；保留最终版本。'),
  task('signoff','26','10:00','10:30','老板确认终版','post','老板 / 策划',true,'获得明确发布确认；此审批时段为倒排拟定，实际记录待核对。'),
  { ...task('publish','26','10:44','11:00','作品发布','post','发布负责人',false,'公开页已核对的发布时间为10:44；结束时刻11:00仅表示本表预留的发布后检查窗口。'), verified: true },
]
export const minutes = (s: string) => { const [h,m] = s.split(':').map(Number); return h * 60 + m }
export const byTime = (a: Task,b: Task) => `${a.date} ${a.start}`.localeCompare(`${b.date} ${b.start}`)
export function weekLabel(start: string, endExclusive: string): string {
  const first = new Date(start+'T12:00:00'), last = new Date(endExclusive+'T12:00:00')
  last.setDate(last.getDate()-1)
  if (first.getFullYear()===last.getFullYear() && first.getMonth()===last.getMonth()) return `${first.getFullYear()} 年 ${first.getMonth()+1} 月 ${first.getDate()}–${last.getDate()} 日`
  return `${first.getFullYear()}.${first.getMonth()+1}.${first.getDate()} – ${last.getFullYear()}.${last.getMonth()+1}.${last.getDate()}`
}
export function validateTask(t: Task): string {
  if (!t.title?.trim() || !t.owner?.trim()) return '请填写事项名称和负责人。'
  if (!/^\d{4}-\d{2}-\d{2}$/.test(t.date) || Number.isNaN(Date.parse(t.date)) || new Date(t.date).toISOString().slice(0,10) !== t.date) return '请选择有效日期。'
  if (![t.start,t.end].every(v => /^([01]\d|2[0-3]):[0-5]\d$/.test(v))) return '请填写有效的开始和结束时间。'
  if (minutes(t.end) <= minutes(t.start)) return '结束时间必须晚于开始时间。'
  if (minutes(t.start) < 480 || minutes(t.end) > 1140) return '日程请安排在08:00—19:00内。'
  if (!Object.hasOwn(phases,t.phase)) return '请选择有效阶段。'
  return ''
}
export function bossConflict(t: Task, tasks: Task[]): boolean {
  return t.boss && tasks.some(x => x.id !== t.id && x.boss && x.date === t.date && minutes(x.start) < minutes(t.end) && minutes(t.start) < minutes(x.end))
}
export function isTasks(value: unknown): value is Task[] {
  if (!Array.isArray(value) || value.length > 500) return false
  const ids = new Set<string>()
  return value.every(t => {
    if (!t || typeof t !== 'object') return false
    if (!['id','title','date','start','end','phase','owner','location','output','note'].every(k => typeof t[k] === 'string')) return false
    if (typeof t.boss !== 'boolean' || !t.id || ids.has(t.id) || validateTask(t)) return false
    ids.add(t.id); return true
  })
}
export const csvCell = (s: string) => '"' + (/^[\s]*[=+@-]/.test(s) ? "'" + s : s).replaceAll('"','""') + '"'
