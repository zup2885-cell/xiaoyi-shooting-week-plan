import test from 'node:test'
import assert from 'node:assert/strict'
import { bossConflict, csvCell, isTasks, minutes, sample, seedTasks, validateTask, weekLabel } from '../src/plan.ts'
test('示例日期、时间、ID和负责人完整，发布锚点一致',()=>{
  assert.equal(isTasks(seedTasks),true)
  assert.equal(new Set(seedTasks.map(t=>t.id)).size,seedTasks.length)
  const publish=seedTasks.find(t=>t.id==='publish')!
  assert.equal(`${publish.date} ${publish.start}`,sample.published)
  assert.equal(publish.verified,true)
  assert.equal(seedTasks.filter(t=>t.verified).length,1)
  for(const t of seedTasks){assert.equal(validateTask(t),'');assert.equal(bossConflict(t,seedTasks),false);assert.ok(t.output.length>0);assert.ok(t.date>='2026-04-20'&&t.date<='2026-04-26')}
})
test('安排有休息、准备和备份，老板无需提早等团队布置',()=>{
  const setup=seedTasks.find(t=>t.id==='setup')!,arrival=seedTasks.find(t=>t.id==='arrival')!,backup=seedTasks.find(t=>t.id==='backup')!
  assert.ok(minutes(setup.end)<=minutes(arrival.start));assert.equal(setup.boss,false);assert.equal(backup.boss,false)
  assert.equal(seedTasks.find(t=>t.id==='lunch')!.end,'13:00');assert.ok(backup.output.includes('备份'))
})
test('拒绝反向时间、越界、无效日期和损坏缓存',()=>{
  const t=seedTasks[0]
  assert.ok(validateTask({...t,end:t.start}));assert.ok(validateTask({...t,start:'07:30'}));assert.ok(validateTask({...t,date:'2026-02-30'}));assert.ok(validateTask({...t,start:'29:00'}))
  assert.equal(isTasks([{id:'broken'}]),false);assert.equal(isTasks([...seedTasks,seedTasks[0]]),false);assert.equal(isTasks(null),false)
})
test('老板参与冲突检查允许相邻时段、阻止交叉',()=>{
  const t=seedTasks.find(t=>t.id==='arrival')!
  assert.equal(bossConflict({...t,id:'new',start:'09:15',end:'09:45'},seedTasks),true)
  assert.equal(bossConflict({...t,id:'new',start:'18:00',end:'18:30'},seedTasks),false)
  assert.equal(bossConflict({...t,id:'new',boss:false},seedTasks),false)
})
test('CSV引用、逗号及公式输入安全转义',()=>{
  assert.equal(csvCell('普通,文字'),'"普通,文字"');assert.equal(csvCell('a"b'),'"a""b"');assert.equal(csvCell('=1+1'),'"\'=1+1"')
})
test('跨月和跨年周标题完整显示两端日期',()=>{
  assert.equal(weekLabel('2026-04-20','2026-04-27'),'2026 年 4 月 20–26 日')
  assert.equal(weekLabel('2026-04-27','2026-05-04'),'2026.4.27 – 2026.5.3')
  assert.equal(weekLabel('2026-12-28','2027-01-04'),'2026.12.28 – 2027.1.3')
})
